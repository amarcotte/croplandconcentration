// JavaScript Document


console.log(us_cropland[0].y1945);
console.log(us_cropland[0].y1945 / us_cropland[0].sqmiles);

//function find_Crop_Concentration(y1945) {
//	// cycle through all neighborhoods
//	for (i = 0; i < us_cropland.length; i++) {
//		var crop_concentration1945 = us_cropland[i].y1945 / us_cropland[i].sqmiles
//		matchList.push(i);
//	}
//};

function crop_decoder(sqmiles){	
	// Decode big or small based on square miles
	if(sqmiles >= 100000){
		return 'big';
	}
	else if(sqmiles < 100000) {
		return 'small';
	}
	else {
		return false;
	}
}

var crop_data = [];
$.each(us_cropland, function(key, data){
 
	// Grab the square miles in that state
	var sq_miles = data.sqmiles;
 
	// Grab the abbreviation of that state
	var state_abbreviation = data.abbr;
 
	// Create a JSON object containing the state abbreviation
	// and whether or not the state is "big" or "small"
	var datarow = {"state_abbr": state_abbreviation,
		       "big_or_small": crop_decoder(sq_miles)
		       };
 
	// Add that JSON object to our data
	crop_data.push(datarow);
 
});

var state = d3.selectAll('path').attr('fill', function(d){
 
	// Get the ID of the path we are currently working with
	// Our SVG uses the state abbreviation for the ID
	var abbr = this.id;
 
	// Loop through the crop data looking for
	// a match for that abbreviation
	// Then returning the corresponding president
	// who won that state, from the array we made earlier
	$.each(crop_data, function(key, data){
		if(data.state_abbr == abbr){
			size = data.big_or_small;
		}
	})
 
	// Return colors
	// based on data					
	if(size == "small"){
		return "#a8e1a0"
	}
	else if(size == "big"){
		return "#77bb6d"
	}
	else {
		return "#CCC"
	}
});